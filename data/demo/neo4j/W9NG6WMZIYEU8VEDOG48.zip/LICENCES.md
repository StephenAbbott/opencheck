# OpenCheck export — licence notes

This bundle was generated for query `W9NG6WMZIYEU8VEDOG48` (kind: entity). It combines data from multiple open-data sources, each with its own licence. The **most restrictive** licence applies to the combined dataset for re-use.

## Compatibility

🔴 **NOT for commercial use — a non-commercial source is included.**

- Commercial use: **no**
- Attribution required: **yes**
- Share-alike obligations: **yes**

> ⚠️ Not for commercial use — this bundle includes non-commercial source(s): OpenSanctions (CC-BY-NC-4.0). Remove their statements before any commercial use.

> ⚠️ Share-alike obligations apply — derivative works of OpenCorporates (OC-Terms) must be released under the same licence.

> ⚠️ Verify terms — bespoke or per-collection licence(s): OpenAleph (per-collection).

## Source licence matrix

| | Source | Licence | Commercial | Attribution | Share-alike |
|---|---|---|---|---|---|
| 🟢 | Global Energy Monitor / Climate TRACE (`climatetrace`) | CC-BY-4.0 | yes | yes | no |
| 🟢 | CVR — Det Centrale Virksomhedsregister (`cvr_denmark`) | Danish Open Government Data (CVR brugervilkår) | yes | yes | no |
| 🟢 | GLEIF (`gleif`) | CC0-1.0 | yes | no | no |
| 🟡 | OpenAleph (`openaleph`) | per-collection | conditional | yes | no |
| 🟡 | OpenCorporates (`opencorporates`) | OC-Terms | conditional | yes | yes |
| 🟡 | OpenSanctions (`opensanctions`) | CC-BY-NC-4.0 | no | yes | no |
| 🟢 | Wikidata (`wikidata`) | CC0-1.0 | yes | no | no |
| 🟢 | Wikirate (`wikirate`) | CC-BY-4.0 | yes | yes | no |

## Attribution

### Global Energy Monitor / Climate TRACE (`climatetrace`)

- **Licence**: CC-BY-4.0
- **Homepage**: https://globalenergymonitor.org/
- **Attribution**: Global Energy Monitor, CC BY 4.0. Climate TRACE, CC BY 4.0. GLEIF GEM Entity ID-to-LEI mapping, CC BY 4.0.

### CVR — Det Centrale Virksomhedsregister (`cvr_denmark`)

- **Licence**: Danish Open Government Data (CVR brugervilkår)
- **Homepage**: https://datacvr.virk.dk/
- **Attribution**: Indeholder data fra Det Centrale Virksomhedsregister (CVR), Erhvervsstyrelsen / Danish Business Authority. Data distribueret via Datafordelerens CVR GraphQL API.

### GLEIF (`gleif`)

- **Licence**: CC0-1.0
- **Homepage**: https://search.gleif.org/#/search/
- **Attribution**: Contains LEI data from GLEIF, available under CC0 1.0.

### OpenAleph (`openaleph`)

- **Licence**: per-collection
- **Homepage**: https://openaleph.org/
- **Attribution**: Data from OpenAleph — per-collection license; see each source card for the specific terms.

### OpenCorporates (`opencorporates`)

- **Licence**: OC-Terms
- **Homepage**: https://opencorporates.com/
- **Attribution**: Contains company data from OpenCorporates (https://opencorporates.com/). Licensed per-jurisdiction under the source government registry license.

### OpenSanctions (`opensanctions`)

- **Licence**: CC-BY-NC-4.0
- **Homepage**: https://www.opensanctions.org/
- **Attribution**: Data from OpenSanctions.org, licensed CC BY-NC 4.0.

### Wikidata (`wikidata`)

- **Licence**: CC0-1.0
- **Homepage**: https://www.wikidata.org/wiki/Wikidata:Main_Page
- **Attribution**: Wikidata structured data, CC0 1.0.

### Wikirate (`wikirate`)

- **Licence**: CC-BY-4.0
- **Homepage**: https://wikirate.org/
- **Attribution**: Wikirate.org, licensed under CC BY 4.0

## Specific notices

- **opensanctions/gem-own-e100000001607** — OpenSanctions is licensed under CC-BY-NC-4.0. Commercial re-use of this data is not permitted under the source license.

---

_This licensing summary is informational only and is not legal advice. Verify each source's licence terms before commercial use or redistribution._
