# OpenCheck export — licence notes

This bundle was generated for query `FRDRIPF3EKNDJ2CQJL29` (kind: entity). It combines data from multiple open-data sources, each with its own licence. The **most restrictive** licence applies to the combined dataset for re-use.

## Compatibility

🟡 **Commercial use may be restricted — verify the flagged sources.**

- Commercial use: **conditional**
- Attribution required: **yes**
- Share-alike obligations: **yes**

> ⚠️ Share-alike obligations apply — derivative works of OpenCorporates (OC-Terms) must be released under the same licence.

> ⚠️ Verify terms — bespoke or per-collection licence(s): OpenAleph (per-collection).

## Source licence matrix

| | Source | Licence | Commercial | Attribution | Share-alike |
|---|---|---|---|---|---|
| 🟢 | GLEIF (`gleif`) | CC0-1.0 | yes | no | no |
| 🟡 | OpenAleph (`openaleph`) | per-collection | conditional | yes | no |
| 🟡 | OpenCorporates (`opencorporates`) | OC-Terms | conditional | yes | yes |
| 🟢 | Wikidata (`wikidata`) | CC0-1.0 | yes | no | no |
| 🟢 | Wikirate (`wikirate`) | CC-BY-4.0 | yes | yes | no |

## Attribution

### GLEIF (`gleif`)

- **Licence**: CC0-1.0
- **Homepage**: https://search.gleif.org/#/search/
- **Attribution**: Contains LEI data from GLEIF, available under CC0 1.0.

### OpenAleph (`openaleph`)

- **Licence**: per-collection
- **Homepage**: https://openaleph.org/
- **Attribution**: Data from OpenAleph — per-collection license; see each source card for the specific terms.

### OpenCorporates (`opencorporates`)

- **Licence**: OC-Terms
- **Homepage**: https://opencorporates.com/
- **Attribution**: Contains company data from OpenCorporates (https://opencorporates.com/). Licensed per-jurisdiction under the source government registry license.

### Wikidata (`wikidata`)

- **Licence**: CC0-1.0
- **Homepage**: https://www.wikidata.org/wiki/Wikidata:Main_Page
- **Attribution**: Wikidata structured data, CC0 1.0.

### Wikirate (`wikirate`)

- **Licence**: CC-BY-4.0
- **Homepage**: https://wikirate.org/
- **Attribution**: Wikirate.org, licensed under CC BY 4.0

---

_This licensing summary is informational only and is not legal advice. Verify each source's licence terms before commercial use or redistribution._
