# OpenCheck export — licence notes

This bundle was generated for query `5493005044RTLQ5RZU70` (kind: entity). It combines data from multiple open-data sources, each with its own licence. The **most restrictive** licence applies to the combined dataset for re-use.

## Compatibility

🔴 **NOT for commercial use — a non-commercial source is included.**

- Commercial use: **no**
- Attribution required: **yes**
- Share-alike obligations: **no**

> ⚠️ Not for commercial use — this bundle includes non-commercial source(s): OpenSanctions (CC-BY-NC-4.0). Remove their statements before any commercial use.

> ⚠️ Verify terms — bespoke or per-collection licence(s): OpenAleph (per-collection).

## Source licence matrix

| | Source | Licence | Commercial | Attribution | Share-alike |
|---|---|---|---|---|---|
| 🟢 | Estonian e-Business Register (e-Äriregister) (`ariregister`) | CC-BY-4.0 | yes | yes | no |
| 🟢 | Global Energy Monitor / Climate TRACE (`climatetrace`) | CC-BY-4.0 | yes | yes | no |
| 🟢 | GLEIF (`gleif`) | CC0-1.0 | yes | no | no |
| 🟡 | OpenAleph (`openaleph`) | per-collection | conditional | yes | no |
| 🟡 | OpenSanctions (`opensanctions`) | CC-BY-NC-4.0 | no | yes | no |
| 🟢 | TED — Tenders Electronic Daily (EU procurement) (`ted_eu`) | EU open data — Commission Decision 2011/833/EU (free reuse incl. commercial, with attribution) | yes | yes | no |
| 🟢 | Wikidata (`wikidata`) | CC0-1.0 | yes | no | no |

## Attribution

### Estonian e-Business Register (e-Äriregister) (`ariregister`)

- **Licence**: CC-BY-4.0
- **Homepage**: https://ariregister.rik.ee/eng
- **Attribution**: Data from the Estonian e-Business Register (e-Äriregister), published by the Centre of Registers and Information Systems (RIK), CC BY 4.0.

### Global Energy Monitor / Climate TRACE (`climatetrace`)

- **Licence**: CC-BY-4.0
- **Homepage**: https://globalenergymonitor.org/
- **Attribution**: Global Energy Monitor, CC BY 4.0. Climate TRACE, CC BY 4.0. GLEIF GEM Entity ID-to-LEI mapping, CC BY 4.0.

### GLEIF (`gleif`)

- **Licence**: CC0-1.0
- **Homepage**: https://search.gleif.org/#/search/
- **Attribution**: Contains LEI data from GLEIF, available under CC0 1.0.

### OpenAleph (`openaleph`)

- **Licence**: per-collection
- **Homepage**: https://openaleph.org/
- **Attribution**: Data from OpenAleph — per-collection license; see each source card for the specific terms.

### OpenSanctions (`opensanctions`)

- **Licence**: CC-BY-NC-4.0
- **Homepage**: https://www.opensanctions.org/
- **Attribution**: Data from OpenSanctions.org, licensed CC BY-NC 4.0.

### TED — Tenders Electronic Daily (EU procurement) (`ted_eu`)

- **Licence**: EU open data — Commission Decision 2011/833/EU (free reuse incl. commercial, with attribution)
- **Homepage**: https://ted.europa.eu/
- **Attribution**: Contains procurement notice data from Tenders Electronic Daily (TED), © European Union, via ted.europa.eu.

### Wikidata (`wikidata`)

- **Licence**: CC0-1.0
- **Homepage**: https://www.wikidata.org/wiki/Wikidata:Main_Page
- **Attribution**: Wikidata structured data, CC0 1.0.

## Specific notices

- **opensanctions/gem-own-e100000000358** — OpenSanctions is licensed under CC-BY-NC-4.0. Commercial re-use of this data is not permitted under the source license.

---

_This licensing summary is informational only and is not legal advice. Verify each source's licence terms before commercial use or redistribution._
